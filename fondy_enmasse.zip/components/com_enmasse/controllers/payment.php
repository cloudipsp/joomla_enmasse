<?php
/* ------------------------------------------------------------------------
  # En Masse - Social Buying Extension 2010
  # ------------------------------------------------------------------------
  # By Matamko.com
  # Copyright (C) 2010 Matamko.com. All Rights Reserved.
  # @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
  # Websites: http://www.matamko.com
  # Technical Support:  Visit our forum at www.matamko.com
  ------------------------------------------------------------------------- */
// No direct access 
defined( '_JEXEC' ) or die( 'Restricted access' ); 

jimport('joomla.application.component.controller');
require_once( JPATH_ADMINISTRATOR . DS ."components". DS ."com_enmasse". DS ."helpers". DS ."DatetimeWrapper.class.php");
require_once( JPATH_ADMINISTRATOR . DS ."components". DS ."com_enmasse". DS ."helpers". DS ."EnmasseHelper.class.php");
require_once( JPATH_SITE . DS ."components". DS ."com_enmasse". DS ."helpers". DS ."Cart.class.php");
require_once( JPATH_SITE . DS ."components". DS ."com_enmasse". DS ."helpers". DS ."CartHelper.class.php");

class EnmasseControllerPayment extends JControllerLegacy
{
	function gateway()
	{
		JRequest::setVar('view', 'paygty');
		parent::display();
	}

	function returnUrl_()
	{
		sleep(2);
		$msg = JText::_("PAYMENT_BEING_PROCESS_MSG");
		$link = JRoute::_("index.php?option=com_enmasse&controller=order&view=orderList", false);
		JFactory::getApplication()->redirect($link, $msg);
	}
	
        function notifyUrl()
	{
		$session = & JFactory::getSession();
		$user = JFactory::getUser();
	
		$orderId 	= JRequest::getVar('orderId');
		$payClass 	= JRequest::getVar('payClass', '');
		
		$className = 'PayGty'.ucfirst($payClass);
		if (!(EnmasseHelper::checkValidPayclass($payClass)))
		{
				$msg = "Invalid pay class";
				$link = JRoute::_("index.php?option=com_enmasse&controller=deal", false);
				JFactory::getApplication()->redirect($link, $msg);
				die;
		}
		require_once JPATH_SITE . DS ."components". DS ."com_enmasse". DS ."helpers". DS ."payGty". DS .$payClass. DS .$className. ".class.php";

		if ( ! call_user_func_array(array($className, "validateTxn"), array($payClass)) )
		{
			echo JTEXT::_("PAYMENT_VALIDATION_FAILED");
			exit(0);
		}
		else
		{
			$payDta = call_user_func_array(array($className, "generatePaymentDetail"), array());	
			$payDetail = json_encode($payDta);	
                        
			if($payClass=="paypal")
			{
				$payDta = call_user_func_array(array($className, "generatePaymentDetail"), array());	
				$payDetail = json_encode($payDta);
				JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);
				
				$link = JRoute::_("index.php?option=com_enmasse&controller=payment&task=doNotify&$postData&orderId=$orderId", false);
				JFactory::getApplication()->redirect($link);
			}elseif($payClass=="fondy"){
				if (empty($_POST)){
					$fap = json_decode(file_get_contents("php://input"));
					$_POST = array();
					foreach($fap as $key=>$val){
						$_POST[$key] =  $val ;
					}
				}	
				$order_status = JRequest::getVar('order_status','','POST');
				$invoice_number = JRequest::getVar('order_id','','POST');
				if ($invoice_number == ''){
					$invoice_number = $_POST['order_id'];
				}
				if ($order_status == ''){
					$order_status = $_POST['order_status'];
				}
				if($order_status == 'approved')
				{
					$orderId = explode('#',$invoice_number)[0];
					
					EnmasseHelper::doNotify($orderId);
					JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);									
					$transactionid = stripslashes( $_POST['payment_id']);
					$msg = JText::_( "Thank you for purchasing! Your transaction ID is " . $transactionid . ".");
					
				}
				$link = JRoute::_("index.php?option=com_enmasse&controller=deal", false);
				JFactory::getApplication()->redirect($link, $msg);
			}	
			
			         
		}
		$session->clear('newOrderId');
        }
        
	function returnUrl()
	{	
            //********** Already using notifyUrl (return back to home page)*******************
                $link = JRoute::_(JURI::base(), false);
		JFactory::getApplication()->redirect($link);
            //*********** End return ************
                
                
		$session = & JFactory::getSession();
		$user = JFactory::getUser();
	
		$orderId 	= JRequest::getVar('orderId');
		$payClass 	= JRequest::getVar('payClass', '');
		
		$className = 'PayGty'.ucfirst($payClass);
		if (!(EnmasseHelper::checkValidPayclass($payClass)))
		{
				$msg = "Invalid pay class";
				$link = JRoute::_("index.php?option=com_enmasse&controller=deal", false);
				JFactory::getApplication()->redirect($link, $msg);
				die;
		}
		require_once JPATH_SITE . DS ."components". DS ."com_enmasse". DS ."helpers". DS ."payGty". DS .$payClass. DS .$className. ".class.php";

		if ( ! call_user_func_array(array($className, "validateTxn"), array($payClass)) )
		{
			echo JTEXT::_("PAYMENT_VALIDATION_FAILED");
			exit(0);
		}
		else
		{
			$payDta = call_user_func_array(array($className, "generatePaymentDetail"), array());	
			$payDetail = json_encode($payDta);		
			if($payClass=="pagseguro")
			{
				header('Content-Type: text/html; charset=ISO-8859-1');
				$Referencia  = JRequest::getVar('Referencia',NULL,'post');
				if(isset($Referencia))
				{
					$orderId = stripslashes( $_POST['Referencia'] );
					$order = JModelLegacy::getInstance('order','enmasseModel')->getById($orderId);
					if($order == null)
					{
						echo JTEXT::_("PAYMENT_ERROR_MSG") . $orderId;
						exit(0);
					}
					else if($order->status=="Unpaid") // Pass checking
					{
						switch(stripslashes($_POST['StatusTransacao']))
						{
							case "Completo": //Full payment
								EnmasseHelper::doNotify($orderId);			
								break;
							case "Aguardando Pagto": //Awaiting Customer Payment
								EnmasseHelper::setPendingStatusByOrderId($orderId);
								break;
							case "Aprovado": //Payment approved, awaiting compensation
								EnmasseHelper::doNotify($orderId);
								break;
							//case "Em An...": //Payment approved, under reviewing by Pagseguro
								//break;
							case "Cancelado": //Cancelled
								EnmasseHelper::setRefundedStatusByOrderId($orderId);
								break;																								
							default:
								$msg = "Muito obrigado por seu pedido!";
								$link = JRoute::_("index.php?option=com_enmasse&controller=deal", false);
								JFactory::getApplication()->redirect($link, $msg);
								break;								
						}
						JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);								
					}
				}	
				else					
				{
					$msg = "Muito obrigado por seu pedido!";
					$link = JRoute::_("index.php?option=com_enmasse&controller=deal", false);
					JFactory::getApplication()->redirect($link, $msg);	
				}
			}
			elseif($payClass=="payfast")
			{
				$paymentstatus = JRequest::getVar('payment_status','','POST') ;
				if(isset($paymentstatus))
				{
					$flag	= JRequest::getVar('flag');							
					
					if($paymentstatus == "COMPLETE")
					{
						$orderId = JRequest::getVar('m_payment_id','','POST') ;
						EnmasseHelper::doNotify($orderId);
						JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);
					}
				}
				$msg = '';
				if(stripslashes( $_GET['flag'] )=="returnUrl")
				{
					$msg = JText::_( "Thank you for purchasing!");
				}
				else if( stripslashes( $_GET['flag'] )=="cancelUrl")
				{
					$msg = JText::_( "Your payment was cancelled.");
				}					
				$link = JRoute::_("index.php?option=com_enmasse&controller=deal", false);	
				JFactory::getApplication()->redirect($link, $msg);
			}
			elseif($payClass=="twocheckout")
			{
				$payGty = JModelLegacy::getInstance('payGty','enmasseModel')->getByClass($payClass);
				$attribute_config = json_decode($payGty->attribute_config);
				$accountNumber = $attribute_config->sid;
				$demo = $attribute_config->demo;
				if($demo == "Y" &&  $_REQUEST["credit_card_processed"] == "Y")
				{
					$orderId = $_REQUEST["cart_order_id"];
					EnmasseHelper::doNotify($orderId);
					JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);		
					$msg = JText::_( "Thank you for purchasing!");					
				} // md5 checking is only available in live payment
				elseif(demo != "Y" &&  $_REQUEST["credit_card_processed"] == "Y")
				{				
					$secretWord = $attribute_config->secret_word;
					$string_to_hash = $secretWord . $accountNumber . $_REQUEST["order_number"] . $_REQUEST["total"];
					$check_key = strtoupper(md5($string_to_hash));
					if($check_key == $_REQUEST["key"])
					{						
						$orderId = $_REQUEST["cart_order_id"];
						EnmasseHelper::doNotify($orderId);
						JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);
						$msg = JText::_( "Thank you for purchasing!");
					}
					else 
					{
						$msg = JText::_( "Can't verify your payment! Please contact Administrator!");
					}
				}
				$link = JRoute::_("index.php?option=com_enmasse&controller=deal", false);
				JFactory::getApplication()->redirect($link, $msg);
			}
			elseif($payClass=="authorizenet")
			{
				$approved = JRequest::getVar('approved','','POST');
				$invoice_number = JRequest::getVar('invoice_number','','POST');
				if($approved=='true');
				{
					$orderId = $invoice_number;
					EnmasseHelper::doNotify($orderId);
					JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);									$transactionid = stripslashes( $_POST['transaction_id']);
					$msg = JText::_( "Thank you for purchasing! Your transaction ID is " . $transactionid . ".");
				}
				$link = JRoute::_("index.php?option=com_enmasse&controller=deal", false);
				JFactory::getApplication()->redirect($link, $msg);
			}
			elseif($payClass=="ewayhosted")
			{			
				if($_REQUEST['trxnstatus']=='true');
				{
					$orderId = $_REQUEST['orderId'];
					EnmasseHelper::doNotify($orderId);
					JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);					
					$msg = JText::_( "Thank you for purchasing!");
				}
				$link = JRoute::_("index.php?option=com_enmasse&view=orderlist", false);
				JFactory::getApplication()->redirect($link, $msg);
			}			
			elseif($payClass=="paypal")
			{
				$payDta = call_user_func_array(array($className, "generatePaymentDetail"), array());	
				$payDetail = json_encode($payDta);
				JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);
				
				$link = JRoute::_("index.php?option=com_enmasse&controller=payment&task=doNotify&$postData&orderId=$orderId", false);
				JFactory::getApplication()->redirect($link);
			}	
			elseif($payClass=="moneybookers")
			{				
				$transaction_id = JRequest::getVar('transaction_id','','post');
				$status = JRequest::getVar('status','','post');
				if(isset($transaction_id) && $status == 2)
				{
                    $orderId = $transaction_id;
                    if(EnmasseHelper::getOrderStatusByOrderId($orderId) == "Unpaid")
                    {
                        EnmasseHelper::doNotify($orderId);
                        JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail); 
                    }
				}               
            }
			elseif($payClass=="ogone")
			{				
				$aData = array();
				foreach($_REQUEST as $key=>$value)
				{
					$aData[strtoupper($key)] = $value;
				}			
				$orderId = $aData['ORDERID'];
				if($aData['STATUS'] == '5' || $aData['STATUS'] == '9')
				{
					EnmasseHelper::doNotify($orderId);
					JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);
					$sMessage = JText::_('PAYMENT_BEING_PROCESS_MSG');					
				}
				else
				{
					$sMessage = JTEXT::_("PAYMENT_VALIDATION_FAILED");	
				}
				$link = JRoute::_("/", false);
				JFactory::getApplication()->redirect($link, $sMessage);
            }
            elseif($payClass=="googlecheckout")
            {
            	$merchantId = '624370439819433';
            	$merchantKey = 'r86DDFDkmjzrqrr7kW_NMQ';
            	$authorization = base64_encode($merchantId.':'.$merchantKey);
            	header('Authorization: Basic '.$authorization);
            	header('Content-Type: application/xml;charset=UTF-8');
            	header('Accept: application/xml;charset=UTF-8');
            	
            	$serial_number = $_REQUEST['serial-number'];
            	
				$orderId = $session->get( 'newOrderId', 0 );
				if (isset($orderId) && $orderId) {
	            	EnmasseHelper::doNotify($orderId);
	            	JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);
				}
            	
            	echo '<?xml version="1.0" encoding="UTF-8"?>
            			<notification-acknowledgment xmlns="http://checkout.google.com/schema/2" serial-number="'.$serial_number.'"/>';
            	exit;
            }
			elseif($payClass=="realex")
			{			
				if($_REQUEST['RESULT']=='00');
				{
					$orderId = $_REQUEST['ORDER_ID'];
					EnmasseHelper::doNotify($orderId);
					JModelLegacy::getInstance('order','enmasseModel')->updatePayDetail($orderId, $payDetail);					
					$msg = JText::_( "Thank you for purchasing!");
				}
				$link = JRoute::_("index.php?option=com_enmasse&view=orderlist", false);
				JFactory::getApplication()->redirect($link, $msg);
			}         
		}
		$session->clear('newOrderId');
	}

	function doNotify()
	{		
		$orderId = JRequest::getVar("orderId", null);
		
		$order = JModelLegacy::getInstance('order','enmasseModel')->getById($orderId);
		if($order == null)
		{
			echo JTEXT::_("PAYMENT_ERROR_MSG") . $orderId;
			exit(0);
		}
		else if($order->status=="Unpaid") // Pass checking
		{
			EnmasseHelper::doNotify($orderId);
		}
                //free cart
                JFactory::getSession()->set('cart', null);
		$msg = JTEXT::_("PAYMENT_SUCCESS");
                $menuItemId = JFactory::getApplication()->getMenu()->getItems('link','index.php?option=com_enmasse&view=deallisting',true)->id;
		$link = JRoute::_("index.php?option=com_enmasse&view=deallisting&Itemid=".$menuItemId, false);
		JFactory::getApplication()->redirect($link, $msg);
	}

	function cancelUrl()
	{
		$msg = JText::_( "CANCEL_TRANSACTION");
                $menuItemId = JFactory::getApplication()->getMenu()->getItems('link','index.php?option=com_enmasse&view=deallisting',true)->id;
		$link = JRoute::_("index.php?option=com_enmasse&view=deallisting&Itemid=".$menuItemId, false);
		JFactory::getApplication()->redirect($link, $msg);
	}

}
?>