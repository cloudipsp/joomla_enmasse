<?php
/* ------------------------------------------------------------------------
  # En Masse - Social Buying Extension 2010
  # ------------------------------------------------------------------------
  # By Matamko.com
  # Copyright (C) 2010 Matamko.com. All Rights Reserved.
  # @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
  # Websites: http://www.matamko.com
  # Technical Support:  Visit our forum at www.matamko.com
  ------------------------------------------------------------------------- */
// No direct access 
defined( '_JEXEC' ) or die( 'Restricted access' ); 
include ('fondy.php');

// load language pack
$language = JFactory::getLanguage();
$base_dir = JPATH_SITE.DS.'components'.DS.'com_enmasse';
$version = new JVersion;
$joomla = $version->getShortVersion();
if(substr($joomla,0,3) >= '1.6'){
    $extension = 'com_enmasse16';
}else{
    $extension = 'com_enmasse';
}
if($language->load($extension, $base_dir, $language->getTag(), true) == false)
{
	 $language->load($extension, $base_dir, 'en-GB', true);
}

$site = JFactory::getDocument();
$site->setTitle(JText::_('CHECK_OUT_BUTTON')); 
$cartItem = array_pop($this->cart->getAll());
$price = $cartItem->item->price * $cartItem->item->prepay_percent / 100;
$price_to_f = round($price*100);
$sReturnUrl = JURI::root() . 'index.php?option=com_enmasse&controller=payment&task=returnUrl&orderId=' . $this->orderId;
$returnUrl = JURI::root() . 'index.php?option=com_enmasse&controller=payment&task=notifyUrl&payClass=fondy';
$desq = $cartItem->item->short_desc;
if ($desq == '' )
	$desq = 'Order Pay: ' . $this->orderId;
$order_id = $this->orderId . '#' . time();
$data = [
'merchant_id'=> $this->attributeConfig->MerchanID,
'order_id'=> $order_id,
'amount'=> $price_to_f * $cartItem->getCount(),
'currency'=> $this->attributeConfig->Currency,
'order_desc'=> $desq,
'response_url'=> $returnUrl,
'server_callback_url'=> $returnUrl,
];
$signature = Fondy::getSignature($data, $this->attributeConfig->SecretKey);
?>

  <form name="paymentForm" method="POST" action="https://api.fondy.eu/api/checkout/redirect/">
      <input type="hidden" type="text" name="server_callback_url" value="<?php echo $returnUrl; ?>">
      <input type="hidden" type="text" name="response_url" value="<?php echo $returnUrl; ?>">
      <input type="hidden" type="text" name="order_id" value="<?php echo $order_id; ?>">
      <input type="hidden" type="text" name="order_desc" value="<?php echo $desq ?>">
      <input type="hidden" type="text" name="currency" value="<?php echo $this->attributeConfig->Currency?>">
      <input type="hidden" type="text" name="amount" value="<?php echo ($price_to_f * $cartItem->getCount()); ?>">
      <input type="hidden" type="text" name="signature" value="<?php echo $signature; ?>">
      <input type="hidden" type="text" name="merchant_id" value="<?php echo $this->attributeConfig->MerchanID?>">
      <input type="hidden" type="submit">
    </form>
<?php echo JText::_('Вы будете перенаправлены через несколько секунд...'); ?>
<script>
    document.paymentForm.submit();
</script>